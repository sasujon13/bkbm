# media_manager/urls.py
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = []

# Add a URL pattern to serve media files
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)